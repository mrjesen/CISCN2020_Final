<?php
 $mysqli = new mysqli("localhost", "b1ind", "ilikectf", "flag");
?>
